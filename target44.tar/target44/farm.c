/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_408(unsigned *p)
{
    *p = 2425362456U;
}

void setval_366(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_241(unsigned x)
{
    return x + 3281031288U;
}

unsigned getval_172()
{
    return 3267856712U;
}

void setval_227(unsigned *p)
{
    *p = 3347663057U;
}

void setval_104(unsigned *p)
{
    *p = 3284601160U;
}

unsigned getval_352()
{
    return 1490493858U;
}

unsigned addval_443(unsigned x)
{
    return x + 2421707925U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_213()
{
    return 3375944073U;
}

void setval_376(unsigned *p)
{
    *p = 3767355618U;
}

void setval_223(unsigned *p)
{
    *p = 2495777185U;
}

void setval_390(unsigned *p)
{
    *p = 2447411528U;
}

void setval_200(unsigned *p)
{
    *p = 3525889673U;
}

void setval_427(unsigned *p)
{
    *p = 3771287570U;
}

unsigned addval_454(unsigned x)
{
    return x + 3682910729U;
}

unsigned addval_467(unsigned x)
{
    return x + 3674784409U;
}

unsigned addval_492(unsigned x)
{
    return x + 163762569U;
}

unsigned getval_204()
{
    return 3524841097U;
}

unsigned addval_435(unsigned x)
{
    return x + 3525366153U;
}

unsigned addval_216(unsigned x)
{
    return x + 3682128265U;
}

unsigned getval_378()
{
    return 3229143433U;
}

unsigned getval_318()
{
    return 3286272320U;
}

unsigned addval_401(unsigned x)
{
    return x + 3224948361U;
}

unsigned getval_361()
{
    return 3252717896U;
}

unsigned addval_486(unsigned x)
{
    return x + 3531919625U;
}

unsigned addval_150(unsigned x)
{
    return x + 3677933193U;
}

unsigned addval_423(unsigned x)
{
    return x + 3286272328U;
}

void setval_214(unsigned *p)
{
    *p = 2429462910U;
}

unsigned addval_141(unsigned x)
{
    return x + 3223375369U;
}

void setval_109(unsigned *p)
{
    *p = 3767093462U;
}

unsigned addval_126(unsigned x)
{
    return x + 3375940232U;
}

unsigned getval_173()
{
    return 2464188744U;
}

unsigned addval_442(unsigned x)
{
    return x + 3221799593U;
}

void setval_278(unsigned *p)
{
    *p = 2446231841U;
}

void setval_195(unsigned *p)
{
    *p = 3374371211U;
}

void setval_388(unsigned *p)
{
    *p = 3523793293U;
}

unsigned getval_128()
{
    return 3526935177U;
}

void setval_187(unsigned *p)
{
    *p = 3380920969U;
}

void setval_299(unsigned *p)
{
    *p = 3373846153U;
}

unsigned getval_406()
{
    return 3247489673U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
